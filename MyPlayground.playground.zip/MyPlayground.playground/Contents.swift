var str = "Hello, there"

// Start coding here
